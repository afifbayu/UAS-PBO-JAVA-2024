public class Note {
    // ID catatan
    private int id;
    // Deskripsi catatan
    private String description;

    // Konstruktor untuk menginisialisasi ID dan deskripsi catatan
    public Note(int id, String description) {
        this.id = id;
        this.description = description;
    }

    // Mendapatkan ID catatan
    public int getId() {
        return id;
    }

    // Mendapatkan deskripsi catatan
    public String getDescription() {
        return description;
    }

    // Mengembalikan representasi string dari catatan
    @Override
    public String toString() {
        // Format string untuk menampilkan ID dan deskripsi catatan
        return "ID: " + id + " | Deskripsi: " + description;
    }
}
