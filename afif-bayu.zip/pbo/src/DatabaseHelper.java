import java.sql.*;

public class DatabaseHelper {
    // URL koneksi basis data SQLite
    private static final String DB_URL = "jdbc:sqlite:notes.db";
    // Objek Connection untuk berkomunikasi dengan basis data
    private Connection connection;

    // Konstruktor untuk inisialisasi koneksi basis data dan membuat tabel jika belum ada
    public DatabaseHelper() {
        try {
            // Muat driver SQLite
            Class.forName("org.sqlite.JDBC");
            // Buat koneksi ke basis data menggunakan URL yang ditentukan
            connection = DriverManager.getConnection(DB_URL);
            // Buat tabel jika belum ada
            createTable();
            System.out.println("Database connected successfully."); // Pesan debug
        } catch (ClassNotFoundException e) {
            System.err.println("Driver JDBC SQLite tidak ditemukan."); // Pesan kesalahan jika driver tidak ditemukan
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace(); // Pesan kesalahan jika terjadi masalah dengan koneksi SQL
        }
    }

    // Metode untuk membuat tabel 'notes' jika belum ada
    private void createTable() {
        try (Statement stmt = connection.createStatement()) {
            // SQL untuk membuat tabel 'notes' dengan kolom id dan description
            String createTableSQL = "CREATE TABLE IF NOT EXISTS notes ("
                    + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "description TEXT NOT NULL)";
            stmt.execute(createTableSQL); // Eksekusi pernyataan SQL untuk membuat tabel
        } catch (SQLException e) {
            e.printStackTrace(); // Pesan kesalahan jika terjadi masalah saat membuat tabel
        }
    }

    // Metode untuk menambahkan catatan baru ke basis data
    public void addNote(String description) {
        if (connection != null) {
            // SQL untuk menyisipkan catatan baru
            String insertSQL = "INSERT INTO notes (description) VALUES (?)";
            try (PreparedStatement pstmt = connection.prepareStatement(insertSQL)) {
                pstmt.setString(1, description); // Setel deskripsi catatan
                pstmt.executeUpdate(); // Eksekusi pernyataan SQL untuk menambahkan catatan
                System.out.println("Note added: " + description); // Pesan debug
            } catch (SQLException e) {
                e.printStackTrace(); // Pesan kesalahan jika terjadi masalah saat menambahkan catatan
            }
        } else {
            System.err.println("Database connection is not available."); // Pesan kesalahan jika koneksi tidak tersedia
        }
    }

    // Metode untuk mengambil semua catatan dari basis data
    public ResultSet getAllNotes() {
        if (connection != null) {
            // SQL untuk memilih semua catatan, diurutkan berdasarkan ID secara menurun
            String query = "SELECT * FROM notes ORDER BY id DESC";
            try (Statement stmt = connection.createStatement()) {
                ResultSet rs = stmt.executeQuery(query); // Eksekusi kueri dan ambil hasilnya
                return rs; // Kembalikan ResultSet yang berisi catatan
            } catch (SQLException e) {
                e.printStackTrace(); // Pesan kesalahan jika terjadi masalah saat mengambil catatan
            }
        }
        return null; // Kembalikan null jika koneksi tidak tersedia
    }

    // Metode untuk menghapus catatan berdasarkan ID
    public void deleteNoteById(int id) {
        if (connection != null) {
            // SQL untuk menghapus catatan berdasarkan ID
            String deleteSQL = "DELETE FROM notes WHERE id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(deleteSQL)) {
                pstmt.setInt(1, id); // Setel ID catatan yang akan dihapus
                pstmt.executeUpdate(); // Eksekusi pernyataan SQL untuk menghapus catatan
                System.out.println("Note deleted with ID: " + id); // Pesan debug
            } catch (SQLException e) {
                e.printStackTrace(); // Pesan kesalahan jika terjadi masalah saat menghapus catatan
            }
        }
    }
}
