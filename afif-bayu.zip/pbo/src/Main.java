import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Membuat objek Scanner untuk membaca input dari pengguna
        Scanner scanner = new Scanner(System.in);
        // Membuat objek NoteManager untuk mengelola catatan
        NoteManager noteManager = new NoteManager();
        
        // Loop utama untuk menampilkan menu dan memproses input pengguna
        while (true) {
            // Menampilkan menu utama
            System.out.println("Menu:");
            System.out.println("1. Tambah Catatan");
            System.out.println("2. Tampilkan Catatan");
            System.out.println("3. Hapus Catatan");
            System.out.println("4. Keluar");
            System.out.print("Pilih opsi: ");
            
            // Memeriksa apakah input berikutnya adalah angka
            if (scanner.hasNextInt()) {
                // Membaca opsi yang dipilih oleh pengguna
                int option = scanner.nextInt();
                scanner.nextLine(); // Mengonsumsi newline setelah membaca angka
                
                // Menangani pilihan pengguna berdasarkan opsi yang dipilih
                switch (option) {
                    case 1:
                        // Menambahkan catatan
                        System.out.print("Masukkan deskripsi catatan: ");
                        String noteText = scanner.nextLine();
                        noteManager.addNote(noteText);
                        break;
                    case 2:
                        // Menampilkan semua catatan
                        noteManager.displayNotes();
                        break;
                    case 3:
                        // Menghapus catatan berdasarkan ID
                        System.out.print("Masukkan ID catatan yang ingin dihapus: ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); // Mengonsumsi newline setelah membaca angka
                        noteManager.deleteNote(id);
                        break;
                    case 4:
                        // Keluar dari aplikasi
                        System.out.println("Keluar...");
                        scanner.close();
                        System.exit(0);
                        break;
                    default:
                        // Menampilkan pesan jika opsi tidak valid
                        System.out.println("Opsi tidak valid.");
                }
            } else {
                // Menampilkan pesan jika input tidak valid
                System.out.println("Input tidak valid. Harap masukkan angka.");
                scanner.nextLine(); // Mengonsumsi input yang tidak valid
            }
        }
    }
}
