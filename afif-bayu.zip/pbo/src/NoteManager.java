import java.sql.ResultSet;
import java.sql.SQLException;

public class NoteManager {
    // Instance dari DatabaseHelper untuk berinteraksi dengan basis data
    private DatabaseHelper dbHelper;

    // Konstruktor untuk menginisialisasi DatabaseHelper
    public NoteManager() {
        dbHelper = new DatabaseHelper();
    }

    // Metode untuk menambahkan catatan baru
    public void addNote(String description) {
        // Tambahkan catatan ke basis data menggunakan DatabaseHelper
        dbHelper.addNote(description);
        System.out.println("Note added."); // Pesan konfirmasi bahwa catatan telah ditambahkan
    }

    // Metode untuk menampilkan semua catatan
    public void displayNotes() {
        // Ambil semua catatan dari basis data
        ResultSet rs = dbHelper.getAllNotes();
        try {
            // Periksa apakah ResultSet tidak null
            if (rs != null) {
                // Iterasi melalui semua hasil dalam ResultSet
                while (rs.next()) {
                    // Ambil ID dan deskripsi catatan dari ResultSet
                    int id = rs.getInt("id");
                    String description = rs.getString("description");
                    // Buat objek Note dengan ID dan deskripsi
                    Note note = new Note(id, description);
                    // Tampilkan catatan menggunakan metode toString() dari Note
                    System.out.println(note);
                }
            } else {
                System.out.println("ResultSet is null."); // Pesan jika ResultSet null
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Pesan kesalahan jika terjadi masalah dengan ResultSet
        }
    }

    // Metode untuk menghapus catatan berdasarkan ID
    public void deleteNote(int id) {
        // Hapus catatan dari basis data menggunakan DatabaseHelper
        dbHelper.deleteNoteById(id);
        System.out.println("Note deleted."); // Pesan konfirmasi bahwa catatan telah dihapus
    }
}
